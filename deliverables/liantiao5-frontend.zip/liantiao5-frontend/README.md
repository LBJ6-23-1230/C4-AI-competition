# 知学 Mate · 前端工作包（liantiao5）

> **收件人**：前端同学
> **生成日期**：见压缩包内文件时间
> **基线**：后端 207/207 测试 · HTTP 联调 82/82 · 演示基线 12/12 无漂移

## 这个包里有什么

```
app/                      HarmonyOS ArkTS 工程（你可以直接构建）
  entry/src/main/ets/     源码：pages / services / api / viewmodels / components
  entry/src/test/         前端单测（hypium）
  contracts/openapi.json  接口契约**镜像**（后端真源的副本，逐字相同）
  docs/                   前端回归检查清单、测试方案、小样本体验表
  deliverables/           UI 线框图 PNG
contracts/openapi.json    契约真源副本（方便你对照字段）
docs/                     给你的任务书与相关报告
```

**包里没有**（都是可再生的，避免包体过大）：
`entry/build/`（编译产物，含 HAP）、`oh_modules/`、`.hvigor/`、`.idea/`、`.vscode/`

## 怎么开始

1. **读 `docs/17-前端同学任务书.md`** —— 这是你的工作清单，含验收标准
2. **在 DevEco Studio 里打开 `app/`** —— 目标 SDK 是 API 24（DevEco 6.1.1）
3. **第一件事：Build 一次**。本工程此前编译通过（0 ERROR / 90 WARN），
   但联调侧改过 16 个文件且**无法在本环境编译验证**，需要你确认。

## 你需要知道的关键约定

| 约定 | 说明 |
|---|---|
| 后端地址 | `ApiDefaults.DEFAULT_BASE_URL`，单一真源。模拟器 `10.0.2.2:5000`，真机用开发机局域网 IP |
| 契约头 | 所有 `/api/v1/**` 请求带 `X-API-Contract-Version: api-contract-v0.3` |
| 契约只读 | **不要直接改** `app/contracts/openapi.json`（它是镜像，由联调负责人同步） |
| 身份 | 读自己数据用 `appState.currentUser.userId`，**不要写死 demo-user** |

## 待你完成的（详见任务书）

| 优先级 | 事项 |
|---|---|
| 🔴 | **重新 Build + 真机验证**（16 处改动未编译） |
| 🟠 | 通知 `wantAgent` 深链（复用卡片已有参数协议） |
| 🟠 | 真实模式任务完成度恒 0% |
| 🟡 | 意图框架（2 个意图，鸿蒙 Agent 方向最对口） |

## 需要真机/外部配置的事

* **华为账号一键登录**：需 AppGallery Connect 配 `client_id` + 签名指纹，
  缺任何一条都会失败（代码会把失败原因原样展示，不假装成功）
* **语音识别**：模拟器通常不可用，提前准备降级话术
* **通知深链**：需真机验证点击后是否落到目标页
